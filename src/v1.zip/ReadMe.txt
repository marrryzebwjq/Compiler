******************** Version 1 du compilateur ************************

Les points de générations qui ont été faits pour cette version
comprennent la compilation des :

_ déclarations
_ expressions
_ instructions de base
_ structures de contrôle si, ttq, et cond
_ écriture des fichiers mnémoniques et programme objet mapile en fin de compilation